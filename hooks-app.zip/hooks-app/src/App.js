import logo from './logo.svg';
import './App.css';
import HooksAppDemo from './components/HooksAppDemo';
import NoteApp from './components/NoteApp';
import RestApp from './components/RestApp';
import ContextApp from './components/contextapp/ContextApp';

function App() {
  return (
    <div className="App">
      <ContextApp/>
    </div>
  );
}

export default App;
