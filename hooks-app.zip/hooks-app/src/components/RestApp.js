
import axios from "axios";
import React ,{useState , useEffect} from 'react';
import ShowData from './ShowData';
import RestButton from './RestButton';

const URL="https://jsonplaceholder.typicode.com/users";
function RestApp(props){
    
    const [users,setUser]=useState([]);
    const loadData=(props)=>{
        axios.get(URL).then(res=> res.data).then((data)=>{
            setUser(data)
            
        })
    
    }
   
        return(
            <div>
                <div>
                    <ShowData user={users}/>
                    <RestButton data={loadData}/>
                </div>
            </div>
        )
    }
export default RestApp;