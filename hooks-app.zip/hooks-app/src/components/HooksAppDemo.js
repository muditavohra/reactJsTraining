import React ,{useState , useEffect} from 'react';

function HooksAppDemo(props) {
    const [counter,setCounter]=useState(10)
    const increment=()=>{
        setCounter(counter+1)
    }
    const dec=()=>{
        setCounter(counter-1)
    }

    useEffect(()=>{
        console.log('called on load everytime');
    })

    useEffect(()=>{
        console.log('called on update everytime');
    },[counter])

    return (
        <div>
            <p>Counter is :{counter}</p>
            <button onClick={increment}>INC</button>
            <button onClick={dec}>DEC</button>
        </div>
    );
}

export default HooksAppDemo;