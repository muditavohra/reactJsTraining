import React, {createContext, useState, useContext} from 'react';
const appContext = createContext()
const data = {
    id: 101,
    empName: 'Arun',
    location: 'chennai',
    salary: 123456
}
function ContextApp(props) {
    const [employee, setEmployee] = useState(data)
    return (
        <div>
            <p>Employee Salary :{
                employee.salary
            }</p>


            <appContext.Provider value={
                {
                    data: employee,
                    updateEmployee: setEmployee
                }
            }>
                <Employee/>
            </appContext.Provider>
        </div>
    );
}
function Employee(props) {
    let empContext = useContext(appContext)
    function updateDetails(){
        empContext.updateEmployee({
            ...empContext.data,
            location:'pune'
        })
    }
    return (
        <div>
            Employee Component
            <p>Employee ID :{
                empContext.data.id
            }</p>
            <p>Employee Name :{
                empContext.data.empName
            }</p>
            <p>Employee Loaction :{
                empContext.data.location
            }</p>
            <p>Employee Salary :{
                empContext.data.salary
            }</p>
            <button onClick={updateDetails}>Update Details</button>

            <Salary/>
        </div>
    );
}
function Salary(props) {
    let salaryContext = useContext(appContext)
    function updateIncome() {
        salaryContext.updateEmployee({
            ... salaryContext.data,
            salary: 15000
        })
    }

    return (
        <div>
            Salary :{
            salaryContext.data.salary
        }

            <hr/>
            <button onClick={updateIncome}>Update Salary</button>
        </div>
    );
}
export default ContextApp;