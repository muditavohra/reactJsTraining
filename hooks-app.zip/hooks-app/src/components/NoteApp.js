import React,{ useState } from 'react';

function NoteApp(props) {
    const[users,setUser]=useState([]);
    const[title,setTitle]= useState('')
    const[email,setEmail]=useState('');
    const addUser =(e)=>{
        e.preventDefault()
        setUser([...users,{title,email}])
    
    
    setEmail('')
    setTitle('') //to clear the text box
    }

    const deleteUser=(title)=>{
        setUser (users.filter((note)=> note.title !=title))
    }
    return (
        <div>
            {
                users.map((data) => (
                    <ul key={data.title}>
                        <li>{data.title}</li>
                        <li>{data.email}</li>
                        <button onClick={()=>deleteUser(data.title)}>delete</button>
                    </ul>
                    
                ))
            }           
            <form onSubmit={addUser}>
                UserName:<input type='text' value={title} onChange={(e)=>
                setTitle(e.target.value)}/>
                Email:<input type='email' value={email} onChange={(e)=>
                setEmail(e.target.value)}/>
                <button>add user</button>
            </form>
           
        </div>
    );
}

export default NoteApp;