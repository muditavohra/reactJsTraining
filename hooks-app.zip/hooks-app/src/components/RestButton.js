function RestButton(props){
    return(
        <div>
            
            <button className="btn btn-success"  onClick={props.data}>Load data</button>
        </div>
    )
}

export default RestButton
