import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { loadUserList } from '../redux/actions/userAction';
 function UserDetails(props) {

    const data=useSelector(state => state.usr.userList)
    const dbt=useSelector(state => state.usr.loading)
    const dispatch=useDispatch()

    useEffect(()=>{
     dispatch(loadUserList())
    },[])
    console.log(data);
    
    return (
    dbt ? <div><h2>Loading....</h2></div>:
    
        <div className="card">
            <div className="card-header">
            <h4>User Details</h4>
            </div>
            <div className="card-body">
            <table className="table">
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>City</td>
                        <td>Role</td>
                        <td>Action</td>

                    </tr>
                </thead>
                <tbody>
                    {
                        data.map(item =>
                            
                            <tr>
                                <td>{item.id}</td>
                                <td>{item.name}</td>
                                <td>{item.email}</td>
                                <td>{item.city}</td>
                                <td>{item.role}</td>
                                <td><button className="btn btn-primary">Edit</button> | <button className="btn btn-danger">Delete</button></td> 
                            </tr>
                            )
                    }
                </tbody>
            </table>
        </div>
        </div>
    );
}

export default UserDetails;