import NavigationLink from "./NavigationLink"
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import Login from './Login';
import Register from './Register';
import UserDetails from './UserDetails';
import Portfolio from './Portfolio';
import PageNotFound from './PageNotFound';
import LandingPage from "./LandingPage";
import { ToastContainer } from 'react-toastify'

function AppRouter(){

    return(
<div>
    <BrowserRouter>
    <div>
    <NavigationLink/>
    <Switch>
        <Route path="/" exact={true} component={LandingPage}/> 
        <Route path="/login" component={Login}/>
        <Route path="/register" component={Register}/>
        <Route path="/userdetails" component={UserDetails}/>
        <Route path="/portfolio" component={Portfolio}/>
        <Route  component={PageNotFound}/>
    </Switch>
    </div>
    </BrowserRouter>
    <ToastContainer></ToastContainer>
    </div>
)

}
export default AppRouter