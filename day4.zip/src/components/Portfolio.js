import React from 'react';

function Portfolio(props) {
    return (
        <div>
            Portfolio
        </div>
    );
}

export default Portfolio;