import {MAKE_REQUEST, FAIL_REQUEST, GET_USER_LIST} from "../constants/ActionTypes"
import axios from 'axios'


export const makeRequest = () => {
    return {type: MAKE_REQUEST}
}
export const failRequest = (err) => {
    return {type: FAIL_REQUEST, payload: err}
}
export const getUserList = (data) => {
    return {type: GET_USER_LIST, payload: data}
}
export const loadUserList = () => {
    return(dispatch) => {
        dispatch(makeRequest())
        setTimeout(() => {
            axios.get('http://localhost:8000/usersdata').then(res => {
            const userList = res.data
            dispatch(getUserList(userList))
        }).catch(err => {
            dispatch(failRequest(err.message))
        })
        }, 1000);
        
    }
}
