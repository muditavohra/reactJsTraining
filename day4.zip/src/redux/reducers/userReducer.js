import {MAKE_REQUEST, FAIL_REQUEST, GET_USER_LIST} from "../constants/ActionTypes"

const initialState = {
    loading: true,
    userList: [],
    userobj: {},
    errMsg: ''
}
export const userReducer = (state = initialState, action) => {
    switch (action.type) {
        case MAKE_REQUEST:
            return {
                ...state,
                loading: true
            }
        case FAIL_REQUEST:
            return {
                ...state,
                loading: false,
                errMsg: action.payload
            }
        case GET_USER_LIST:
            return {
                ...state,
                loading: false,
                errMsg: '',
                userList: action.payload,
                userobj: {}
            }
        default:
            return state
    }
}
