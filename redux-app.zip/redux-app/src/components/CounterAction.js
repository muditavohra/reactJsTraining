import React from 'react';
import { useDispatch } from 'react-redux';
import { increment } from '../redux/actions/counterAction';
import { decrement } from '../redux/actions/counterAction';
import {reset} from '../redux/actions/counterAction';

function CounterAction(props) {
    const dispatch=useDispatch()
    return (
    <div>
        <button onClick={()=> dispatch(increment())}>Increment</button>
        <button onClick={()=> dispatch(decrement())}>decrement</button>
        <button onClick={()=> dispatch(reset())}>reset</button>
    </div>   
    );
}

export default CounterAction;