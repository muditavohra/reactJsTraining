import React from 'react'
import { mount } from 'enzyme'

import Account from '../components/Account'
import UserApp from '../components/UserApp'

it('check for rendering',()=>{
    const wrapper= mount(<UserApp/>)
    expect(wrapper.state("error")).toEqual(null)
})

it('check for property',()=>{
    const wrapper=mount(<UserApp/>)
    const header=<h1>User data </h1>
    expect(wrapper.contains(header)).toEqual(true)
})
const user={
    name:'andrew',
    email:'andrew@mail.com',
    username:'Dave'
}

it('check for data',()=>{
    const wrapper=mount(<Account user={user}/>)
    const value=wrapper.find("p").text()

    expect(value).toEqual('andrew@mail.com')
})