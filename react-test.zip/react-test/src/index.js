import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

import * as serviceWorker from "./serviceWorker";
import UserApp from "./components/UserApp";


ReactDOM.render(<UserApp />, document.getElementById("root"));

serviceWorker.register();
