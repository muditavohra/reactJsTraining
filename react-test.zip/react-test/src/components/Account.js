import React from 'react';

function Account({user}) {
    return (
        <div>
            <h4>{user.name}</h4>
            <p>{user.email}</p>
        </div>
    );
}

export default Account;