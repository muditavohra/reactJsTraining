
import './App.css';
import MainApp from './components/MainApp';
import RestApp from "./components/RestApp";

function App() {
  return (
    <div className="App">

      welcome
      <MainApp/>
      <RestApp/>
    </div>
  );
}

export default App;
