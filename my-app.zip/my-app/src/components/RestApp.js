import { Component } from "react";
import axios from "axios";
import ShowData from "./ShowData";
import RestButton from "./RestButton";

const URL="https://jsonplaceholder.typicode.com/users";
export default class RestApp extends Component{
   /*  componentDidMount(){
        axios.get(URL).then(res=> res.data).then((data)=>console.log(data));
    } */

    state={
        users:[]
    }
    loadData=()=>{
        console.log('load data');
        axios.get(URL).then(res=> res.data).then((data)=>{
            this.setState({users:data})
            
        })
    
    }
    render(){
        return(
            <div>
                <div>
                    <ShowData user={
                        this.state.users
                    }/>
                    <RestButton data={
                        this.loadData
                    }/>
                </div>
            </div>
        )
    }
}