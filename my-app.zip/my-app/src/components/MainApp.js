import { Component } from "react";
import Footer from "./Footer";
import Header from "./Header";
import Users from "./Users";
import AddUser from "./AddUser";
import Counterapp from "./Counterapp";


export default class MainApp extends Component {
    state={
    headerMessage:'welcome to header',
    footerMessage:'Welcome to Footer',
    userdata:[]
    }

    addUser=(data)=>{
        this.setState((prevState)=>{
            return{
                userdata:prevState.userdata.concat(data)
            };
        });
    }

    deleteAll=()=>{
        this.setState(()=>{
            return{
                userdata:[]
            }
        });
    }

    deleteUser=(user)=>{
        this.setState((prevState)=>{
            return{
                userdata:prevState.userdata.filter((option)=> user!==option)
            }
        })
    }

    
  render() {
    
    return (
      <div>
        
        <Header hm={this.state.headerMessage}/>
        <p>welcome to MainApp</p>
        <Users ud={this.state.userdata} da={this.deleteAll} datasize={this.state.userdata.length>0}
         du={this.deleteUser} />
        <AddUser au={this.addUser}/>
        <Counterapp/>
        
        <Footer fm={this.state.footerMessage}/>
      </div>
    );
  }
}
