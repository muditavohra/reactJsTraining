


function ShowData(props) {
   
        return (


            <table class="table">
                <thead>
                    <tr>

                        <th scope="col">Name</th>
                        <th scope="col">Email</th>

                    </tr>
                </thead>
                <tbody> {

                    props.user.map((udata) => (
                        <tr key={udata.id}>

                            <td> {
                                udata.name
                            }</td>
                            <td> {
                                udata.email
                            }</td>

                        </tr>

                    ))
                } </tbody>
            </table>

        )
    }
export default ShowData

