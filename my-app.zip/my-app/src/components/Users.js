import { Component } from "react";
import User from "./User";

export default class Users extends Component{
    
    render(){
        return(
            <div>
                {this.props.ud.map((data) => <User usr={data} duser={this.props.du}></User>) }
                <button disabled={!this.props.datasize}
                onClick={this.props.da}>deleteAll</button>
               
            </div>
        )
    }
}