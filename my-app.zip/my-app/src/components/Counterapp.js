import {Component} from "react";

export default class Counterapp extends Component{
    state={
        counter:0,
        myname:'amar'
    };
    increment=(e)=>{
        e.preventDefault();
        this.setState((prevState) =>{
            return {
                counter:prevState.counter + 1,
                myname:prevState.myname="mudita"
            };
        });

    };
    decrement=(e)=>{
        e.preventDefault();
        this.setState((prevStat) => {
            return{
                counter:prevStat.counter-1,
                myname:prevStat.myname="riya"
            };
        });
    };
    reset=(e)=>{
        e.preventDefault();
        alert('reset');
    };
  
        render(){
            return(
                <div>
                    <p>The counter is:{this.state.counter}</p>
                    <p>My Name: {this.state.myname} </p>
                    <form>
                        <button onClick={this.increment}>Increment</button>
                        <button onClick={this.decrement}>Decrement</button>
                        <button onClick={this.reset}>Reset</button>
                    </form>
                </div>
            )
        }
}