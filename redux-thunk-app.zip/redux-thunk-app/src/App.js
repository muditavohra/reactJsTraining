import logo from './logo.svg';
import './App.css';
import UserApp from './components/UserApp';

function App() {
  return (
    <div className="App">
      <UserApp/>
    </div>
  );
}

export default App;
