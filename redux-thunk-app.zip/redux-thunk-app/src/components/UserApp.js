import React ,{useEffect} from 'react';
import {useSelector,useDispatch} from 'react-redux'
import {getUsers} from '../redux/appSlice';

function UserApp(props) {
    const data= useSelector(state=> state.userdata.users)
    const dispatch=useDispatch()
    const callUser=()=>{
        dispatch(getUsers())
    }

   /*  useEffect(()=>{
        dispatch(getUsers())
    },[dispatch]) */
    console.log(data)
    return (
        <div>
            <button onClick={callUser}>Load User</button>
            {data.map((udata=>(
            <div>
                <ul>
                    <li>{udata.firstname}</li>
                </ul>
                </div>
                )))}
        </div>
    );
}

export default UserApp;