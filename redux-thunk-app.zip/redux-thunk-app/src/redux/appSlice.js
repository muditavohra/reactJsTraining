import {createAsyncThunk , createSlice} from '@reduxjs/toolkit'

export const getUsers=createAsyncThunk(
    'users/getUsers',
    async()=>{
        const response=await fetch('https://dummyjson.com/users')
        const fromattedres= await response.json()
        return fromattedres
    }
)

export const userSlice = createSlice({

    name:'userdata',
    initialState:{
        users:[],
    },

extraReducers:{
    [getUsers.pending] :(state)=>{
        state.loading=true
    },
    [getUsers.fulfilled] :(state,action)=>{
        state.users=action.payload
    },
    [getUsers.rejected] :(state)=>{
        state.loading=false
    },
}
})
export default userSlice.reducer